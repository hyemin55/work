export const message = Symbol();
export const reversedMessage = Symbol();
