<script>
import FirstChild from "@/components/FirstChild.vue";
export default {
  components: {
    FirstChild,
  },
};
</script>
<template>
  <FirstChild />
</template>
<style>
h1,
p {
  color: orange !important;
}
</style>
