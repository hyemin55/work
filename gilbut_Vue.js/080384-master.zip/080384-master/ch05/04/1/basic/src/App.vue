<script>
import UserProfile from '@/components/UserProfile.vue';
export default {
  components: {
    UserProfile,
  },
};
</script>
<template>
  <UserProfile name="김철수" age="30" />
</template>
