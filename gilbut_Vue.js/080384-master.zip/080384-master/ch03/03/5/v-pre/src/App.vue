<script>
export default {
  data() {
    return {
      message: 'Hello, Vue JS',
    };
  },
};
</script>
<template>
  <div v-pre>{{ message }}</div>
</template>
