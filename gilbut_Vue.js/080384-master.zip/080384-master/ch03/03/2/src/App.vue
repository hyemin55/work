<script>
export default {
  data() {
    return {
      name: '철수',
      age: 19,
    };
  },
};
</script>
<template></template>
<style></style>
