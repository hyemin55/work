<script>
export default {
  data() {
    return {
      firstName: 'Gildong',
      lastName: 'Hong',
    };
  },
};
</script>
<template>
  <h1>{{ lastName }} {{ firstName }}</h1>
  <h1>{{ lastName }} {{ firstName }}</h1>
</template>
