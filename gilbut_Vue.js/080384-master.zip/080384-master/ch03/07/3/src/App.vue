<template>
  <h1>Internal Style</h1>
</template>
<style>
  @import './assets/main.css';
</style>
