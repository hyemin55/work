<template>
  <h1>Internal Style</h1>
</template>
<style>
h1 {
  color: red;
  font-style: italic;
}
</style>
