<script></script>
<template>
  <h1 style="color: red; font-style: italic">Inline Style</h1>
</template>
